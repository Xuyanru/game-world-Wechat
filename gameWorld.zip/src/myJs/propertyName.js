const propertyName = {
	"ac": "物防",
	"agile": "敏捷",
	"attackspeed": "攻速",
	"curse": "诅咒",
	"dc": "攻击",
	"endure": "持久",
	"hit": "准确",
	"hprecovery": "体力恢复",
	"level": "等级",
	"luck": "幸运",
	"mac": "魔防",
	"magicelude": "魔法躲避",
	"mc": "魔法",
	"poisonelude": "毒物躲避",
	"poisonrecovery": "中毒恢复",
	"prestige": "声望",
	"purity": "纯度",
	"sc": "道术",
	"sex": "性别",
	"sprecovery": "魔法恢复",
}

export default propertyName;